<?php
/**
 * SystemUser REST service
 */
class SystemUserGroupRestService extends AdiantiRecordService
{
    const DATABASE      = 'permission';
    const ACTIVE_RECORD = 'SystemUserGroup';
}