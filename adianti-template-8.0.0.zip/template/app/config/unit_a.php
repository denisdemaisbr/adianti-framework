<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "app/database/unit_a.db",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];