<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "app/database/permission.db",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];
