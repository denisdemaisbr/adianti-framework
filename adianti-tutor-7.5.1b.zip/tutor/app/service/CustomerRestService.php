<?php
class CustomerRestService extends AdiantiRecordService
{
    const DATABASE = 'samples';
    const ACTIVE_RECORD = 'Customer';
}
